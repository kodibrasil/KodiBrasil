# https://github.com/soundcloud/soundcloud-python
"""Python Soundcloud API Wrapper."""

__version__ = '0.4.2'
__all__ = ['Client']

from client import Client
